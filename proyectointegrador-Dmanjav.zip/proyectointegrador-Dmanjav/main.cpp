// Andrés Iván Rodríguez Méndez A01754650
// Diego Manjarrez Viveros A01753486
#include "Catalogo.h"
#include "Video.h"
#include "Episodio.h"
#include "Pelicula.h"
#include "Serie.h"
#include "Streaming.h"
#include "Excepcion.h"

#include <iostream>
#include <string>

using namespace std;

int main()
{

    Streaming stream;
    stream.start();
}