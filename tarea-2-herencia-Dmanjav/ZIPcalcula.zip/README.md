# Programación Orientada a Objetos TC1030

## Tarea Herencia

Se dividirá en dos esta tarea.

- Lee el documento [Tarea_Herencia.pdf](Tarea_Herencia.pdf) y realiza el programa descrito en el.  
- Cada clase deberá tener su propio `archivo .h y .cpp` y 
- Se deberá incluir un diagrama UML que represente su solución  en archivo JPG



### Entrega

1. Sube los archivos via GitHubClassroom
2. Genera un archivo .zip  y súbelo a Canvas